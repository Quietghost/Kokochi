jquery-ui-map version 3.0-beta

Breaking changes:
1. findMarker is now find => $('#map_canvas').gmap('find', 'marker', {}, function() {});
2. AddInfoWindow is removed
3. RDFa/Microformats/Microdata returns different objects
4. Removed jQuery UI dependency - the plugin is no longer a UI plugin.

Documentation: http://code.google.com/p/jquery-ui-map/wiki/Overview

Demo: http://code.google.com/p/jquery-ui-map/

Issues: http://code.google.com/p/jquery-ui-map/issues/list

Discuss at: http://groups.google.com/group/jquery-ui-map-discuss

Packed with http://dean.edwards.name/packer/


